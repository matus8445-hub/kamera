#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
ANDROID_DIR="$ROOT/android"
SDK_DIR="${ANDROID_HOME:-$HOME/Android/Sdk}"

if [[ ! -d "$SDK_DIR/platforms/android-35" ]]; then
  echo "Android SDK platform android-35 sa nenašla v: $SDK_DIR"
  echo 'Najprv nainštaluj platformu a Build Tools 35 pomocou sdkmanager.'
  exit 1
fi

GRADLE=""
if [[ -x "$HOME/KaliCameraClient/gradle-8.9/bin/gradle" ]]; then
  GRADLE="$HOME/KaliCameraClient/gradle-8.9/bin/gradle"
elif command -v gradle >/dev/null 2>&1 && gradle --version 2>/dev/null | grep -q 'Gradle 8'; then
  GRADLE="$(command -v gradle)"
else
  CACHE="$HOME/.cache/kalicamera-gradle"
  mkdir -p "$CACHE"
  if [[ ! -x "$CACHE/gradle-8.9/bin/gradle" ]]; then
    cd "$CACHE"
    if command -v wget >/dev/null 2>&1; then
      wget -q https://services.gradle.org/distributions/gradle-8.9-bin.zip -O gradle-8.9-bin.zip
    else
      curl -fsSL https://services.gradle.org/distributions/gradle-8.9-bin.zip -o gradle-8.9-bin.zip
    fi
    unzip -q -o gradle-8.9-bin.zip
  fi
  GRADLE="$CACHE/gradle-8.9/bin/gradle"
fi

printf 'sdk.dir=%s\n' "$SDK_DIR" > "$ANDROID_DIR/local.properties"
cd "$ANDROID_DIR"
"$GRADLE" --no-daemon assembleDebug
APK="$ANDROID_DIR/app/build/outputs/apk/debug/app-debug.apk"
[[ -f "$APK" ]] || { echo "APK sa nenašlo: $APK"; exit 1; }
DESKTOP="$(xdg-user-dir DESKTOP 2>/dev/null || printf '%s' "$HOME/Desktop")"
mkdir -p "$DESKTOP"
cp "$APK" "$DESKTOP/KaliCameraClient-v2.apk"
echo
echo "BUILD SUCCESSFUL"
echo "APK: $DESKTOP/KaliCameraClient-v2.apk"
