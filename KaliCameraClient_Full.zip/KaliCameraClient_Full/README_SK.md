# KaliCamera Client 2.0 — zdrojový projekt

Toto je transparentný osobný streamovací prototyp: Android po vedomom stlačení tlačidla posiela obraz do dashboardu na Kali. Kamera beží ako foreground service s trvalým systémovým upozornením. Mikrofón je predvolene vypnutý a dá sa zapnúť iba priamo v aplikácii na mobile. Android zobrazí systémový indikátor používania kamery/mikrofónu.

## Čo je v tejto verzii

- QR párovanie mobilu s Kali dashboardom.
- Živý JPEG/MJPEG obraz z Androidu do Kali.
- Predná/zadná kamera ovládaná z Kali.
- Viac zariadení v jednom dashboarde.
- Mikrofón je defaultne vypnutý; jeho zapnutie/vypnutie sa robí na mobile.
- Prehrávanie mikrofónu v Kali a samostatné stíšenie prehrávania na Kali.
- Nastavenie 480p/720p, 5/10/15 FPS a kompresnej kvality.
- Spojenie cez rôzne Wi‑Fi cez Tailscale (oba prístroje musia byť prihlásené do rovnakého tailnetu).

## Dôležité obmedzenia

- Tento projekt nie je skrytá kamera: pri streamovaní zostáva Android foreground notification a systémový indikátor kamery/mikrofónu. Používateľ musí stream spustiť priamo na mobile. Mikrofón sa zapína iba priamo na mobile.
- Stream sa zastaví tlačidlom v aplikácii, tlačidlom v upozornení, príkazom Stop na Kali alebo pri force-stop/reštarte systému. Android a výrobca môžu obmedziť beh služby; nemožno sľúbiť nepretržitý beh na každom modeli.
- Používa `ws://` vnútri Tailscale tunela. Tailscale spojenie medzi zariadeniami šifruje; **neotváraj port 8765 na verejný internet a nerob port-forwarding na routeri**.
- Ak Android výrobca agresívne uspáva aplikácie, môže byť potrebné povoliť jej neobmedzenú batériu. Nerob to, ak nechceš, aby stream pokračoval pri zhasnutej obrazovke.
- Ide o prvú kompletnú zdrojovú zostavu, nie o publikovaný/overený APK. Pred bežným používaním ju otestuj na vlastných zariadeniach.

## 1. Tailscale na Kali a mobile

1. Nainštaluj Tailscale na Kali podľa oficiálneho návodu: https://tailscale.com/docs/install/linux (na Debian-based systémoch dokumentácia uvádza `curl -fsSL https://tailscale.com/install.sh | sh`).
2. V Kali spusti `sudo tailscale up` a prihlás sa.
3. Nainštaluj Tailscale na Android: https://tailscale.com/docs/install/android
4. Prihlás obe zariadenia do toho istého účtu/tailnetu a zapni Tailscale na oboch.
5. V Kali over `tailscale status` a `tailscale ip -4`.

## 2. Spustenie Kali dashboardu

Rozbaľ celý priečinok projektu. V termináli:

```bash
cd ~/KaliCameraClient_Full/kali-server
./run-kali.sh
```

Skript vytvorí Python virtual environment, nainštaluje potrebné balíky a spustí server. V termináli sa zobrazí PIN. Otvor v Kali prehliadači:

```text
http://127.0.0.1:8765
```

Na stránke je QR kód a PIN. Nezdieľaj QR ani PIN s cudzími osobami.

Voliteľne môžeš nastaviť vlastný PIN pred spustením:

```bash
KALICAM_PIN=123456 ./run-kali.sh
```

## 3. Zostavenie Android APK

Na Kali potrebuješ Java 17 alebo novšiu a Android SDK s `platforms;android-35` a `build-tools;35.0.0`. Vytvorenie APK:

```bash
cd ~/KaliCameraClient_Full
./build-apk.sh
```

Skript používa Gradle 8.9 z predchádzajúceho `~/KaliCameraClient/gradle-8.9`, ak ho nájde; inak si stiahne Gradle 8.9. Výsledný APK uloží na plochu ako `KaliCameraClient-v2.apk`.

## 4. Párovanie a spustenie

1. Nainštaluj `KaliCameraClient-v2.apk` do Androidu.
2. Uisti sa, že Tailscale je zapnutý na mobile aj Kali.
3. Otvor mobilnú aplikáciu a stlač **Naskenovať QR z Kali**.
4. Naskenuj QR z Kali dashboardu.
5. Na mobile stlač **Spustiť stream kamery** a povoľ kameru a upozornenia.
6. Telefón sa objaví na dashboarde. Mikrofón je vypnutý.
7. Ak potrebuješ zvuk, otvor aplikáciu na mobile a stlač **Zapnúť mikrofón**, povoľ mikrofón. Potom na Kali v karte zariadenia stlač **Počúvať mikrofón**.
8. Tlačidlo **Stlmiť prehrávanie** na Kali iba stíši zvuk na Kali; nevypne mikrofón telefónu.
9. Ak chceš vypnúť snímanie, stlač **Vypnúť mikrofón** na mobile a **Zastaviť stream** v aplikácii alebo v upozornení.

## 5. Riešenie problémov

- **Server píše, že Tailscale nie je prihlásený:** spusti `sudo tailscale up`, potom `tailscale status`.
- **Mobil sa nepripojí:** Tailscale musí byť zapnutý na oboch zariadeniach a musia byť v tom istom tailnete. Skontroluj, že port 8765 neblokuje lokálny firewall.
- **QR sa neskenuje:** zvýš jas displeja s dashboardom a naskenuj celý QR.
- **APK sa nevytvorí:** skontroluj `java -version`, `echo "$ANDROID_HOME"`, či existuje `~/Android/Sdk/platforms/android-35`, a celý Gradle výstup.
- **Mikrofón nehrá:** zapni ho najprv priamo na mobile; potom stlač Počúvať mikrofón na Kali. Prehliadač musí povoliť prehrávanie zvuku po kliknutí.
