#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
if ! command -v tailscale >/dev/null 2>&1; then
  echo "Tailscale nie je nainštalovaný. Nainštaluj ho a prihlás Kali do svojho tailnetu."
  exit 1
fi
if ! tailscale status >/dev/null 2>&1; then
  echo "Tailscale nie je prihlásený. Spusti: sudo tailscale up"
  exit 1
fi
if [[ ! -d .venv ]]; then
  python3 -m venv .venv
fi
. .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
python server.py
