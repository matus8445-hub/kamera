#!/usr/bin/env python3
"""KaliCamera dashboard and WebSocket receiver.

The mobile client initiates an outbound WebSocket connection. Use only on a
private Tailscale network; do not port-forward this HTTP service to the public
Internet. The pairing PIN is a shared access token, not a substitute for TLS.
"""
from __future__ import annotations

import asyncio
import json
import os
import secrets
import shutil
import socket
import subprocess
import time
from pathlib import Path
from typing import Any

from aiohttp import web, WSMsgType
import qrcode

HERE = Path(__file__).resolve().parent
PORT = int(os.environ.get("KALICAM_PORT", "8765"))
PIN = os.environ.get("KALICAM_PIN") or f"{secrets.randbelow(1_000_000):06d}"
DEVICES: dict[str, dict[str, Any]] = {}
VIEWERS: dict[web.WebSocketResponse, str | None] = {}


def get_tailscale_ip() -> str:
    override = os.environ.get("KALICAM_HOST", "").strip()
    if override:
        return override
    if not shutil.which("tailscale"):
        raise RuntimeError(
            "Tailscale nie je nainštalovaný. Nainštaluj Tailscale na Kali aj Android, "
            "prihlás obe zariadenia do toho istého tailnetu a spusti server znova."
        )
    try:
        result = subprocess.run(
            ["tailscale", "ip", "-4"], capture_output=True, text=True, timeout=5, check=True
        )
        ip = result.stdout.strip().splitlines()[0]
        if not ip:
            raise RuntimeError("Tailscale nemá pridelenú IPv4 adresu.")
        return ip
    except Exception as exc:
        raise RuntimeError(
            "Nepodarilo sa získať Tailscale IP. Skontroluj `tailscale status` a prihlásenie."
        ) from exc


TAILSCALE_IP = get_tailscale_ip()
DEVICE_WS_URL = f"ws://{TAILSCALE_IP}:{PORT}/ws/device"
PAIR_TEXT = f"KALICAM|{DEVICE_WS_URL}|{PIN}"


def authorized(request: web.Request) -> bool:
    return request.query.get("pin", "") == PIN


def json_error(message: str, status: int = 400) -> web.Response:
    return web.json_response({"error": message}, status=status)


async def index(request: web.Request) -> web.Response:
    local_ip = request.transport.get_extra_info("sockname")[0] if request.transport else ""
    if local_ip not in {"127.0.0.1", "::1"}:
        raise web.HTTPForbidden(text="Dashboard je dostupný iba lokálne na Kali.")
    page = (HERE / "index.html").read_text(encoding="utf-8")
    page = page.replace("__KALICAM_PIN__", PIN)
    page = page.replace("__KALICAM_IP__", TAILSCALE_IP)
    return web.Response(text=page, content_type="text/html")


async def pair_png(request: web.Request) -> web.Response:
    local_ip = request.transport.get_extra_info("sockname")[0] if request.transport else ""
    if local_ip not in {"127.0.0.1", "::1"}:
        raise web.HTTPForbidden(text="QR párovanie je dostupné iba lokálne na Kali.")
    image = qrcode.make(PAIR_TEXT)
    from io import BytesIO
    data = BytesIO()
    image.save(data, format="PNG")
    return web.Response(body=data.getvalue(), content_type="image/png", headers={"Cache-Control": "no-store"})


async def list_devices(request: web.Request) -> web.Response:
    if not authorized(request):
        return json_error("Neplatný PIN.", 401)
    now = time.time()
    result = []
    for device_id, item in list(DEVICES.items()):
        result.append({
            "id": device_id,
            "name": item.get("name", "Android"),
            "facing": item.get("facing", "unknown"),
            "mic": bool(item.get("mic", False)),
            "connected": not item["ws"].closed,
            "age": round(now - item.get("last_seen", now), 1),
            "frames": item.get("frames", 0),
        })
    return web.json_response({"devices": result})


async def send_command(request: web.Request) -> web.Response:
    if not authorized(request):
        return json_error("Neplatný PIN.", 401)
    device_id = request.match_info["device_id"]
    device = DEVICES.get(device_id)
    if not device or device["ws"].closed:
        return json_error("Zariadenie nie je pripojené.", 404)
    try:
        payload = await request.json()
    except Exception:
        return json_error("Neplatné JSON.")
    command = payload.get("cmd")
    if command not in {"front", "back", "stop", "settings"}:
        return json_error("Nepodporovaný príkaz.")
    outbound = {"cmd": command}
    if command == "settings":
        outbound["fps"] = max(3, min(15, int(payload.get("fps", 10))))
        outbound["width"] = 1280 if int(payload.get("width", 640)) >= 1280 else 640
        outbound["height"] = 720 if outbound["width"] == 1280 else 480
        outbound["quality"] = max(35, min(90, int(payload.get("quality", 70))))
    await device["ws"].send_str(json.dumps(outbound))
    return web.json_response({"ok": True})


async def mjpeg_stream(request: web.Request) -> web.StreamResponse:
    if not authorized(request):
        return web.Response(status=401, text="Invalid PIN")
    device_id = request.match_info["device_id"]
    response = web.StreamResponse(
        status=200,
        headers={
            "Content-Type": "multipart/x-mixed-replace; boundary=frame",
            "Cache-Control": "no-store, no-cache, must-revalidate",
            "Pragma": "no-cache",
        },
    )
    await response.prepare(request)
    last_counter = -1
    try:
        while True:
            device = DEVICES.get(device_id)
            if not device:
                await asyncio.sleep(0.25)
                continue
            frame = device.get("frame")
            counter = device.get("frames", 0)
            if frame and counter != last_counter:
                chunk = (
                    b"--frame\r\n"
                    b"Content-Type: image/jpeg\r\n"
                    + f"Content-Length: {len(frame)}\r\n\r\n".encode("ascii")
                    + frame
                    + b"\r\n"
                )
                await response.write(chunk)
                last_counter = counter
            await asyncio.sleep(0.06)
    except (asyncio.CancelledError, ConnectionResetError, BrokenPipeError):
        pass
    return response


async def viewer_ws(request: web.Request) -> web.WebSocketResponse:
    if not authorized(request):
        raise web.HTTPUnauthorized(text="Invalid PIN")
    ws = web.WebSocketResponse(heartbeat=25, max_msg_size=1024 * 1024)
    await ws.prepare(request)
    VIEWERS[ws] = None
    try:
        async for msg in ws:
            if msg.type == WSMsgType.TEXT:
                try:
                    data = json.loads(msg.data)
                    if data.get("watch") in DEVICES:
                        VIEWERS[ws] = data["watch"]
                except Exception:
                    continue
            elif msg.type == WSMsgType.ERROR:
                break
    finally:
        VIEWERS.pop(ws, None)
    return ws


async def device_ws(request: web.Request) -> web.WebSocketResponse:
    if not authorized(request):
        raise web.HTTPUnauthorized(text="Invalid PIN")
    device_id = request.query.get("id", "").strip()
    if not device_id or len(device_id) > 80:
        raise web.HTTPBadRequest(text="Missing device ID")
    name = request.query.get("name", "Android")[:80]
    ws = web.WebSocketResponse(heartbeat=25, max_msg_size=4 * 1024 * 1024)
    await ws.prepare(request)

    old = DEVICES.get(device_id)
    if old and not old["ws"].closed:
        await old["ws"].close(code=4001, message=b"Replaced by new connection")
    DEVICES[device_id] = {
        "ws": ws,
        "name": name,
        "frame": None,
        "frames": 0,
        "facing": "unknown",
        "mic": False,
        "last_seen": time.time(),
    }

    try:
        async for msg in ws:
            item = DEVICES.get(device_id)
            if item is None or item["ws"] is not ws:
                break
            item["last_seen"] = time.time()
            if msg.type == WSMsgType.BINARY:
                packet = msg.data
                if len(packet) < 2:
                    continue
                kind, payload = packet[0], packet[1:]
                if kind == 1:  # JPEG frame
                    item["frame"] = payload
                    item["frames"] += 1
                elif kind == 2:  # PCM16 mono 16 kHz; only sent after local mic opt-in
                    stale = []
                    for viewer, watched_id in list(VIEWERS.items()):
                        if watched_id == device_id and not viewer.closed:
                            try:
                                await viewer.send_bytes(payload)
                            except Exception:
                                stale.append(viewer)
                    for viewer in stale:
                        VIEWERS.pop(viewer, None)
            elif msg.type == WSMsgType.TEXT:
                try:
                    data = json.loads(msg.data)
                    if data.get("type") in {"hello", "status"}:
                        item["name"] = str(data.get("name", item["name"]))[:80]
                        item["facing"] = str(data.get("facing", item["facing"]))[:12]
                        item["mic"] = bool(data.get("mic", item["mic"]))
                except Exception:
                    continue
            elif msg.type in (WSMsgType.CLOSE, WSMsgType.CLOSED, WSMsgType.ERROR):
                break
    finally:
        current = DEVICES.get(device_id)
        if current and current["ws"] is ws:
            DEVICES.pop(device_id, None)
    return ws


async def health(request: web.Request) -> web.Response:
    return web.json_response({"service": "KaliCamera", "status": "running"})


def create_app() -> web.Application:
    app = web.Application(client_max_size=4 * 1024 * 1024)
    app.router.add_get("/", index)
    app.router.add_get("/pair.png", pair_png)
    app.router.add_get("/api/devices", list_devices)
    app.router.add_post("/api/command/{device_id}", send_command)
    app.router.add_get("/stream/{device_id}", mjpeg_stream)
    app.router.add_get("/ws/device", device_ws)
    app.router.add_get("/ws/viewer", viewer_ws)
    app.router.add_get("/health", health)
    return app


if __name__ == "__main__":
    print("=" * 60)
    print("KaliCamera dashboard")
    print(f"Dashboard: http://127.0.0.1:{PORT}")
    print(f"Android WebSocket endpoint: {DEVICE_WS_URL}")
    print(f"Pairing PIN: {PIN}")
    print("QR code is available on the dashboard. Do not port-forward this port.")
    print("Press Ctrl+C to stop the server.")
    print("=" * 60)
    async def serve() -> None:
        runner = web.AppRunner(create_app())
        await runner.setup()
        local_site = web.TCPSite(runner, "127.0.0.1", PORT)
        tailnet_site = web.TCPSite(runner, TAILSCALE_IP, PORT)
        await local_site.start()
        await tailnet_site.start()
        print(f"Listening locally and on Tailscale only (port {PORT}).")
        try:
            await asyncio.Event().wait()
        finally:
            await runner.cleanup()

    try:
        asyncio.run(serve())
    except KeyboardInterrupt:
        print("KaliCamera server stopped.")
