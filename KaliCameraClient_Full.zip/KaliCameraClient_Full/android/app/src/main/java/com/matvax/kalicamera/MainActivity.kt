package com.matvax.kalicamera

import android.Manifest
import androidx.activity.ComponentActivity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import com.journeyapps.barcodescanner.ScanContract
import com.journeyapps.barcodescanner.ScanOptions

class MainActivity : ComponentActivity() {
    private lateinit var status: TextView
    private lateinit var micButton: Button
    private var micEnabled = false

    private val qrLauncher = registerForActivityResult(ScanContract()) { result ->
        val raw = result.contents
        if (raw.isNullOrBlank()) {
            status.text = "QR kód nebol naskenovaný."
            return@registerForActivityResult
        }
        val parts = raw.trim().split('|')
        if (parts.size != 3 || parts[0] != "KALICAM") {
            Toast.makeText(this, "Toto nie je KaliCamera QR kód.", Toast.LENGTH_LONG).show()
            return@registerForActivityResult
        }
        getSharedPreferences(PREFS, MODE_PRIVATE).edit()
            .putString("server_url", parts[1])
            .putString("pin", parts[2])
            .apply()
        status.text = "Kali server spárovaný: ${parts[1]}"
        Toast.makeText(this, "QR párovanie uložené.", Toast.LENGTH_SHORT).show()
    }

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { grants ->
        val cameraOk = grants[Manifest.permission.CAMERA] == true || hasPermission(Manifest.permission.CAMERA)
        if (cameraOk) startCameraService() else status.text = "Bez povolenia kamery sa stream nespustí."
    }

    private val micPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) setMic(true) else Toast.makeText(this, "Mikrofón nebol povolený.", Toast.LENGTH_LONG).show()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        micEnabled = CameraStreamService.isMicActive
        buildUi()
        val savedUrl = getSharedPreferences(PREFS, MODE_PRIVATE).getString("server_url", null)
        status.text = if (savedUrl == null) "Najprv naskenuj QR kód z Kali." else "Server uložený: $savedUrl"
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(28, 34, 28, 28)
            setBackgroundColor(0xFFF2F3F5.toInt())
        }
        val title = TextView(this).apply {
            text = "KaliCamera Client"
            textSize = 25f
            setTextColor(0xFF17202A.toInt())
            gravity = Gravity.CENTER
        }
        val subtitle = TextView(this).apply {
            text = "Viditeľné zdieľanie kamery do tvojho Kali počítača"
            textSize = 14f
            setTextColor(0xFF455A64.toInt())
            gravity = Gravity.CENTER
            setPadding(0, 8, 0, 20)
        }
        status = TextView(this).apply {
            textSize = 15f
            setTextColor(0xFF263238.toInt())
            gravity = Gravity.CENTER
            setPadding(12, 16, 12, 20)
        }
        val scan = makeButton("Naskenovať QR z Kali") { scanQr() }
        val start = makeButton("Spustiť stream kamery") { requestCameraAndStart() }
        micButton = makeButton(if (micEnabled) "Vypnúť mikrofón" else "Zapnúť mikrofón") {
            if (micEnabled) setMic(false)
            else if (hasPermission(Manifest.permission.RECORD_AUDIO)) setMic(true)
            else micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }
        val stop = makeButton("Zastaviť stream") { stopStream() }
        val note = TextView(this).apply {
            text = "Kamera sa spustí len po stlačení tlačidla. Mikrofón je štandardne vypnutý. Počas streamu zostáva viditeľné systémové upozornenie a zelený indikátor Androidu."
            textSize = 13f
            setTextColor(0xFF455A64.toInt())
            gravity = Gravity.CENTER
            setPadding(8, 18, 8, 0)
        }
        root.addView(title, matchWrap())
        root.addView(subtitle, matchWrap())
        root.addView(status, matchWrap())
        root.addView(scan, matchWrap())
        root.addView(start, matchWrap())
        root.addView(micButton, matchWrap())
        root.addView(stop, matchWrap())
        root.addView(note, matchWrap())
        setContentView(root)
    }

    private fun makeButton(label: String, action: () -> Unit): Button = Button(this).apply {
        text = label
        textSize = 15f
        isAllCaps = false
        setOnClickListener { action() }
    }

    private fun matchWrap() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT,
        ViewGroup.LayoutParams.WRAP_CONTENT
    ).apply { bottomMargin = 8 }

    private fun scanQr() {
        val options = ScanOptions().apply {
            setDesiredBarcodeFormats(ScanOptions.QR_CODE)
            setPrompt("Naskenuj QR kód z KaliCamera dashboardu")
            setBeepEnabled(false)
            setOrientationLocked(false)
        }
        qrLauncher.launch(options)
    }

    private fun requestCameraAndStart() {
        if (getConnection() == null) {
            Toast.makeText(this, "Najprv naskenuj QR kód z Kali.", Toast.LENGTH_LONG).show()
            return
        }
        val required = mutableListOf(Manifest.permission.CAMERA)
        if (Build.VERSION.SDK_INT >= 33) required.add(Manifest.permission.POST_NOTIFICATIONS)
        val missing = required.filterNot { hasPermission(it) }
        if (missing.isEmpty()) startCameraService() else permissionLauncher.launch(missing.toTypedArray())
    }

    private fun startCameraService() {
        val connection = getConnection() ?: return
        val intent = Intent(this, CameraStreamService::class.java).apply {
            action = CameraStreamService.ACTION_START
            putExtra("server_url", connection.first)
            putExtra("pin", connection.second)
        }
        ContextCompat.startForegroundService(this, intent)
        status.text = "Spúšťam kameru… Po pripojení sa zariadenie zobrazí v Kali dashboarde."
    }

    private fun setMic(enabled: Boolean) {
        if (!CameraStreamService.isActive) {
            Toast.makeText(this, "Najprv spusti stream kamery.", Toast.LENGTH_SHORT).show()
            return
        }
        val serviceIntent = Intent(this, CameraStreamService::class.java).apply {
            action = if (enabled) CameraStreamService.ACTION_MIC_ON else CameraStreamService.ACTION_MIC_OFF
        }
        startService(serviceIntent)
        micEnabled = enabled
        micButton.text = if (enabled) "Vypnúť mikrofón" else "Zapnúť mikrofón"
        status.text = if (enabled) "Mikrofón je aktívny. Vypni ho tlačidlom, keď ho nepotrebuješ." else "Mikrofón je vypnutý."
    }

    private fun stopStream() {
        stopService(Intent(this, CameraStreamService::class.java))
        micEnabled = false
        micButton.text = "Zapnúť mikrofón"
        status.text = "Stream zastavený."
    }

    private fun getConnection(): Pair<String, String>? {
        val prefs = getSharedPreferences(PREFS, MODE_PRIVATE)
        val url = prefs.getString("server_url", null) ?: return null
        val pin = prefs.getString("pin", null) ?: return null
        return url to pin
    }

    private fun hasPermission(permission: String) =
        ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED

    companion object { private const val PREFS = "kalicamera" }
}
