package com.matvax.kalicamera

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.ImageFormat
import android.graphics.Rect
import android.graphics.YuvImage
import android.hardware.camera2.CameraCaptureSession
import android.hardware.camera2.CameraDevice
import android.hardware.camera2.CameraManager
import android.hardware.camera2.CaptureRequest
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.media.ImageReader
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.SystemClock
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import okio.ByteString
import org.json.JSONObject
import java.net.URLEncoder
import java.io.ByteArrayOutputStream
import java.util.UUID
import java.util.concurrent.TimeUnit
import kotlin.math.abs

class CameraStreamService : Service() {
    private val client = OkHttpClient.Builder()
        .pingInterval(20, TimeUnit.SECONDS)
        .retryOnConnectionFailure(true)
        .build()
    private var socket: WebSocket? = null
    private var cameraThread: HandlerThread? = null
    private var cameraHandler: Handler? = null
    private var camera: CameraDevice? = null
    private var session: CameraCaptureSession? = null
    private var reader: ImageReader? = null
    private var facing = "back"
    private var micOn = false
    private var audioRecord: AudioRecord? = null
    @Volatile private var audioRunning = false
    private var lastFrameAt = 0L
    @Volatile private var targetFps = 10
    @Volatile private var targetWidth = 640
    @Volatile private var targetHeight = 480
    @Volatile private var jpegQuality = 70
    private var reconnectHandler = Handler()
    private var reconnecting = false
    @Volatile private var shuttingDown = false
    private var serverUrl = ""
    private var pin = ""
    private var deviceId = ""
    private var deviceName = "Android"

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        cameraThread = HandlerThread("KaliCamera-Camera").also { it.start() }
        cameraHandler = Handler(cameraThread!!.looper)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> {
                serverUrl = intent.getStringExtra("server_url") ?: serverUrl
                pin = intent.getStringExtra("pin") ?: pin
                if (serverUrl.isBlank() || pin.isBlank()) {
                    stopSelf()
                    return START_NOT_STICKY
                }
                deviceId = getSharedPreferences("kalicamera", MODE_PRIVATE)
                    .getString("device_id", null) ?: UUID.randomUUID().toString().also {
                        getSharedPreferences("kalicamera", MODE_PRIVATE).edit().putString("device_id", it).apply()
                    }
                deviceName = Build.MODEL.ifBlank { "Android phone" }
                startForegroundCameraOnly()
                isActive = true
                isMicActive = false
                connectSocket()
                openCamera()
            }
            ACTION_MIC_ON -> enableMic()
            ACTION_MIC_OFF -> disableMic()
            ACTION_SWITCH_FRONT -> switchCamera("front")
            ACTION_SWITCH_BACK -> switchCamera("back")
            ACTION_STOP -> stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun startForegroundCameraOnly() {
        val notification = buildNotification("Kamera aktívna • mikrofón vypnutý")
        if (Build.VERSION.SDK_INT >= 29) {
            ServiceCompat.startForeground(
                this, NOTIFICATION_ID, notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA
            )
        } else startForeground(NOTIFICATION_ID, notification)
    }

    private fun startForegroundWithMic() {
        val notification = buildNotification("Kamera a mikrofón aktívne")
        if (Build.VERSION.SDK_INT >= 29) {
            ServiceCompat.startForeground(
                this, NOTIFICATION_ID, notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
            )
        } else startForeground(NOTIFICATION_ID, notification)
    }

    private fun updateNotification(text: String) {
        val manager = getSystemService(NotificationManager::class.java)
        manager.notify(NOTIFICATION_ID, buildNotification(text))
    }

    private fun buildNotification(text: String): Notification {
        val openIntent = PendingIntent.getActivity(
            this, 1, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val stopIntent = PendingIntent.getService(
            this, 2, Intent(this, CameraStreamService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.presence_video_online)
            .setContentTitle("KaliCamera Client • stream beží")
            .setContentText(text)
            .setContentIntent(openIntent)
            .setOngoing(true)
            .addAction(android.R.drawable.ic_media_pause, "Zastaviť", stopIntent)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(CHANNEL_ID, "KaliCamera stream", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun connectSocket() {
        if (serverUrl.isBlank() || socket != null) return
        val encodedPin = URLEncoder.encode(pin, "UTF-8")
        val url = "$serverUrl?pin=$encodedPin&id=$deviceId&name=${URLEncoder.encode(deviceName, "UTF-8")}"
        val request = Request.Builder().url(url).build()
        socket = client.newWebSocket(request, object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                webSocket.send(JSONObject().put("type", "hello").put("name", deviceName).put("facing", facing).put("mic", micOn).toString())
                reconnecting = false
            }
            override fun onMessage(webSocket: WebSocket, text: String) {
                try {
                    val command = JSONObject(text)
                    when (command.optString("cmd")) {
                        "front" -> switchCamera("front")
                        "back" -> switchCamera("back")
                        "settings" -> {
                            targetFps = command.optInt("fps", targetFps).coerceIn(3, 15)
                            targetWidth = command.optInt("width", targetWidth).coerceIn(320, 1280)
                            targetHeight = command.optInt("height", targetHeight).coerceIn(240, 720)
                            jpegQuality = command.optInt("quality", jpegQuality).coerceIn(35, 90)
                            openCamera()
                        }
                        "stop" -> stopSelf()
                    }
                } catch (_: Exception) { }
            }
            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                socket = null
                scheduleReconnect()
            }
            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                socket = null
                updateNotification("Server nedostupný • opakujem pripojenie")
                scheduleReconnect()
            }
        })
    }

    private fun scheduleReconnect() {
        if (shuttingDown || reconnecting || serverUrl.isBlank()) return
        reconnecting = true
        reconnectHandler.postDelayed({
            reconnecting = false
            if (!shuttingDown && socket == null) connectSocket()
        }, 4000)
    }

    private fun sendBinary(kind: Byte, data: ByteArray) {
        val packet = ByteArray(data.size + 1)
        packet[0] = kind
        System.arraycopy(data, 0, packet, 1, data.size)
        socket?.send(ByteString.of(*packet))
    }

    private fun openCamera() {
        val handler = cameraHandler ?: return
        handler.post {
            try {
                closeCameraInternal()
                val manager = getSystemService(CAMERA_SERVICE) as CameraManager
                val cameraId = manager.cameraIdList.firstOrNull { id ->
                    val orientation = manager.getCameraCharacteristics(id).get(
                        android.hardware.camera2.CameraCharacteristics.LENS_FACING
                    )
                    if (facing == "front") orientation == android.hardware.camera2.CameraCharacteristics.LENS_FACING_FRONT
                    else orientation == android.hardware.camera2.CameraCharacteristics.LENS_FACING_BACK
                } ?: manager.cameraIdList.firstOrNull() ?: return@post
                val characteristics = manager.getCameraCharacteristics(cameraId)
                val map = characteristics.get(android.hardware.camera2.CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)
                val sizes = map?.getOutputSizes(ImageFormat.YUV_420_888)?.toList().orEmpty()
                val chosen = sizes.filter { it.width <= 1280 && it.height <= 720 }
                    .minByOrNull { abs(it.width - targetWidth) + abs(it.height - targetHeight) }
                    ?: sizes.firstOrNull()
                    ?: android.util.Size(640, 480)
                reader = ImageReader.newInstance(chosen.width, chosen.height, ImageFormat.YUV_420_888, 2).also { imageReader ->
                    imageReader.setOnImageAvailableListener({ source ->
                        val image = source.acquireLatestImage() ?: return@setOnImageAvailableListener
                        try {
                            val now = SystemClock.elapsedRealtime()
                            if (now - lastFrameAt >= (1000L / targetFps)) {
                                val bytes = yuvToJpeg(image, jpegQuality)
                                if (bytes != null) sendBinary(TYPE_VIDEO, bytes)
                                lastFrameAt = now
                            }
                        } finally { image.close() }
                    }, handler)
                }
                manager.openCamera(cameraId, object : CameraDevice.StateCallback() {
                    override fun onOpened(device: CameraDevice) {
                        camera = device
                        val target = reader?.surface ?: return
                        device.createCaptureSession(listOf(target), object : CameraCaptureSession.StateCallback() {
                            override fun onConfigured(configured: CameraCaptureSession) {
                                session = configured
                                try {
                                    val request = device.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW).apply {
                                        addTarget(target)
                                        set(CaptureRequest.CONTROL_MODE, CaptureRequest.CONTROL_MODE_AUTO)
                                        set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_ON)
                                    }.build()
                                    configured.setRepeatingRequest(request, null, handler)
                                    socket?.send(JSONObject().put("type", "status").put("name", deviceName).put("facing", facing).put("mic", micOn).toString())
                                    updateNotification(if (micOn) "Kamera a mikrofón aktívne" else "Kamera aktívna • mikrofón vypnutý")
                                } catch (_: Exception) { stopSelf() }
                            }
                            override fun onConfigureFailed(session: CameraCaptureSession) {
                                updateNotification("Kameru sa nepodarilo nakonfigurovať")
                            }
                        }, handler)
                    }
                    override fun onDisconnected(device: CameraDevice) { device.close(); camera = null }
                    override fun onError(device: CameraDevice, error: Int) { device.close(); camera = null; updateNotification("Chyba kamery: $error") }
                }, handler)
            } catch (e: SecurityException) {
                updateNotification("Chýba povolenie kamery")
                stopSelf()
            } catch (e: Exception) {
                updateNotification("Kameru sa nepodarilo spustiť")
            }
        }
    }


    private fun yuvToJpeg(image: android.media.Image, quality: Int): ByteArray? {
        return try {
            val width = image.width
            val height = image.height
            val yPlane = image.planes[0]
            val uPlane = image.planes[1]
            val vPlane = image.planes[2]
            val nv21 = ByteArray(width * height * 3 / 2)
            var out = 0

            val yBuffer = yPlane.buffer
            val yBase = yBuffer.position()
            for (row in 0 until height) {
                val rowStart = yBase + row * yPlane.rowStride
                for (col in 0 until width) {
                    nv21[out++] = yBuffer.get(rowStart + col * yPlane.pixelStride)
                }
            }

            val uBuffer = uPlane.buffer
            val vBuffer = vPlane.buffer
            val uBase = uBuffer.position()
            val vBase = vBuffer.position()
            for (row in 0 until height / 2) {
                val uRow = uBase + row * uPlane.rowStride
                val vRow = vBase + row * vPlane.rowStride
                for (col in 0 until width / 2) {
                    nv21[out++] = vBuffer.get(vRow + col * vPlane.pixelStride)
                    nv21[out++] = uBuffer.get(uRow + col * uPlane.pixelStride)
                }
            }

            val output = ByteArrayOutputStream()
            val yuv = YuvImage(nv21, ImageFormat.NV21, width, height, null)
            val ok = yuv.compressToJpeg(Rect(0, 0, width, height), quality.coerceIn(35, 90), output)
            if (ok) output.toByteArray() else null
        } catch (_: Exception) {
            null
        }
    }

    private fun closeCameraInternal() {
        try { session?.stopRepeating() } catch (_: Exception) { }
        try { session?.close() } catch (_: Exception) { }
        session = null
        try { camera?.close() } catch (_: Exception) { }
        camera = null
        try { reader?.close() } catch (_: Exception) { }
        reader = null
    }

    private fun switchCamera(newFacing: String) {
        if (newFacing == facing) return
        facing = newFacing
        openCamera()
    }

    private fun enableMic() {
        if (micOn) return
        if (checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            updateNotification("Mikrofón nemá povolenie")
            return
        }
        try {
            startForegroundWithMic()
            val sampleRate = 16000
            val minSize = AudioRecord.getMinBufferSize(sampleRate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
            val bufferSize = maxOf(minSize, 4096)
            val recorder = AudioRecord(
                MediaRecorder.AudioSource.MIC,
                sampleRate,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT,
                bufferSize
            )
            if (recorder.state != AudioRecord.STATE_INITIALIZED) {
                recorder.release()
                startForegroundCameraOnly()
                updateNotification("Mikrofón sa nepodarilo spustiť")
                return
            }
            audioRecord = recorder
            recorder.startRecording()
            micOn = true
            isMicActive = true
            audioRunning = true
            updateNotification("Kamera a mikrofón aktívne")
            socket?.send(JSONObject().put("type", "status").put("facing", facing).put("mic", true).toString())
            Thread({
                val buffer = ByteArray(2048)
                while (audioRunning) {
                    val count = try { recorder.read(buffer, 0, buffer.size) } catch (_: Exception) { -1 }
                    if (count > 0 && audioRunning) sendBinary(TYPE_AUDIO, buffer.copyOf(count))
                    else if (count < 0) break
                }
            }, "KaliCamera-Microphone").start()
        } catch (e: Exception) {
            micOn = false
            isMicActive = false
            audioRunning = false
            try { audioRecord?.release() } catch (_: Exception) { }
            audioRecord = null
            if (camera != null) startForegroundCameraOnly()
            updateNotification("Mikrofón sa nepodarilo spustiť")
        }
    }

    private fun disableMic(updateForegroundType: Boolean = true) {
        val wasActive = micOn || audioRecord != null
        audioRunning = false
        micOn = false
        isMicActive = false
        if (!wasActive) return
        try { audioRecord?.stop() } catch (_: Exception) { }
        try { audioRecord?.release() } catch (_: Exception) { }
        audioRecord = null
        if (updateForegroundType && camera != null) startForegroundCameraOnly()
        socket?.send(JSONObject().put("type", "status").put("facing", facing).put("mic", false).toString())
    }

    override fun onDestroy() {
        shuttingDown = true
        audioRunning = false
        disableMic(updateForegroundType = false)
        try { socket?.close(1000, "Stream stopped") } catch (_: Exception) { }
        socket = null
        cameraHandler?.post { closeCameraInternal() }
        cameraThread?.quitSafely()
        cameraThread = null
        reconnectHandler.removeCallbacksAndMessages(null)
        isActive = false
        isMicActive = false
        ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val ACTION_START = "com.matvax.kalicamera.START"
        const val ACTION_MIC_ON = "com.matvax.kalicamera.MIC_ON"
        const val ACTION_MIC_OFF = "com.matvax.kalicamera.MIC_OFF"
        const val ACTION_SWITCH_FRONT = "com.matvax.kalicamera.SWITCH_FRONT"
        const val ACTION_SWITCH_BACK = "com.matvax.kalicamera.SWITCH_BACK"
        const val ACTION_STOP = "com.matvax.kalicamera.STOP"
        @Volatile var isActive: Boolean = false
        @Volatile var isMicActive: Boolean = false
        private const val CHANNEL_ID = "kalicamera_stream"
        private const val NOTIFICATION_ID = 4401
        private const val TYPE_VIDEO: Byte = 1
        private const val TYPE_AUDIO: Byte = 2
    }
}
